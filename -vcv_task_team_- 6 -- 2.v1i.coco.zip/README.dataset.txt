# “vcv_task_team_< 6 >” 2 > 2024-04-12 12:08pm
https://universe.roboflow.com/ai-sy0nz/-vcv_task_team_-6-2

Provided by a Roboflow user
License: CC BY 4.0

