# vcv_task_team_6.3_final > 2024-04-11 10:31pm
https://universe.roboflow.com/vcvtaskteam63-qkcbq/vcv_task_team_6.3_final

Provided by a Roboflow user
License: CC BY 4.0

