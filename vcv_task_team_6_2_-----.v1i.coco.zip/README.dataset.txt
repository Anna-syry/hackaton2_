# vcv_task_team_6_2_Копия > 2024-03-30 8:45pm
https://universe.roboflow.com/vcvtaskteam61/vcv_task_team_6_2_

Provided by a Roboflow user
License: CC BY 4.0

